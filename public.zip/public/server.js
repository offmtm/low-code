const express = require('express');
const archiver = require('archiver');
const app = express();
const port = 3000;
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const ejs = require('ejs');
const mysql = require('mysql');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname, 'index.html'));
});


let pools = {};

app.post('/connect', (req, res) => {
  const { dbType, dbHost, dbUser, dbPassword, dbName, dbTables } = req.body;

  if (dbType === 'mysql') {
    let poolKey = `${dbHost}_${dbName}_${dbUser}`;
    if (!pools[poolKey]) {
      pools[poolKey] = mysql.createPool({
        connectionLimit: 10,
        host: dbHost,
        user: dbUser,
        password: dbPassword,
        database: dbName
      });
    }
    pools[poolKey].getConnection((error, connection) => {
      if (error) {
        console.error('Erro na conexão ao banco de dados:', error);
        res.status(500).send('Erro na conexão ao banco de dados.');
      } else {
        console.log('Conectado com sucesso ao banco de dados MySQL.');
        res.send('Conectado com sucesso ao banco de dados MySQL.');
        connection.release();
      }
    });
  }
  // código para conectar a outros tipos de banco de dados aqui
});



app.post('/create-site-files', async (req, res) => {
  console.log(req.body); // Add this line to log the request body

  const siteDetails = req.body;
  const siteName = siteDetails.siteName.split(' ').join('_').toLowerCase();

const primaryColor = siteDetails.primaryColor || "#ffffff";
const secondaryColor = siteDetails.secondaryColor || "#000000";
const tertiaryColor = siteDetails.tertiaryColor || "#cccccc";
const headerFont = siteDetails.headerFont || "Arial";
const bodyFont = siteDetails.bodyFont || "Arial";

  let templateFile = '';
  
  switch (siteDetails.siteType) {
    case 'blog':
      templateFile = 'blogTemplate.ejs';
      break;
    case 'ecommerce':
      templateFile = 'ecommerceTemplate.ejs';
      break;
    // add other site types here
    case 'portfolio':
      templateFile = 'portfolioTemplate.ejs';
      break;
    default:
      templateFile = 'defaultTemplate.ejs';


  }

  

  try {
    // change `{ site: siteDetails }` to `siteDetails`
    // this allows us to use variables in EJS templates directly
    
const html = await ejs.renderFile(
    path.join(__dirname, './views', templateFile),
    { 
      siteName: siteDetails.siteName,
      logoPath: siteDetails.logoPath || "",
      features: siteDetails.features || {},

      primaryColor: primaryColor,
      secondaryColor: secondaryColor,
      tertiaryColor: tertiaryColor,
      headerFont: headerFont,
      bodyFont: bodyFont,
      layoutChoice: siteDetails.layoutChoice,
      footerContent: siteDetails.footerContent || "",
      search_feature: siteDetails.features && siteDetails.features.search_feature,
      comments_feature: siteDetails.features && siteDetails.features.comments_feature,
      newsletter_feature: siteDetails.features && siteDetails.features.newsletter_feature,
      shopping_cart: siteDetails.features && siteDetails.features.shopping_cart
    }
);

    console.log(html);  // <-- logging HTML content

    let cssTemplate = "";
    let sqlTemplate = "";

    if (siteDetails.siteType == 'blog') {
      cssTemplate = await fs.promises.readFile(path.join(__dirname, './views', 'blogTemplate.css'), 'utf8');
      sqlTemplate = await fs.promises.readFile(path.join(__dirname, './views', 'blogTemplate.sql'), 'utf8');
    }
    else if (siteDetails.siteType == 'ecommerce') {
      cssTemplate = await fs.promises.readFile(path.join(__dirname, './views', 'ecommerceTemplate.css'), 'utf8');
      sqlTemplate = await fs.promises.readFile(path.join(__dirname, './views', 'ecommerceTemplate.sql'), 'utf8');
    } else if (siteDetails.siteType == 'portfolio')
    {
      cssTemplate = await fs.promises.readFile(path.join(__dirname, './views', 'portfolioTemplate.css'), 'utf8');
      sqlTemplate = await fs.promises.readFile(path.join(__dirname, './views', 'portfolioTemplate.sql'), 'utf8');
    } else {
      cssTemplate = await fs.promises.readFile(path.join(__dirname, './views', 'defaultTemplate.css'), 'utf8');
      sqlTemplate = await fs.promises.readFile(path.join(__dirname, './views', 'defaultTemplate.sql'), 'utf8');
    }


    // add other conditions for other site types
    
    if (!fs.existsSync(siteName)){
      fs.mkdirSync(siteName);
    }

    await fs.promises.writeFile(`${__dirname}/${siteName}/index.html`, html, 'utf8');
    console.log('HTML file written');  // <-- logging file write confirmation

    await fs.promises.writeFile(`${__dirname}/${siteName}/style.css`, cssTemplate, 'utf8');
    await fs.promises.writeFile(`${__dirname}/${siteName}/database.sql`, sqlTemplate, 'utf8');

    const output = fs.createWriteStream(`${__dirname}/${siteName}.zip`);
    const archive = archiver('zip', {
      zlib: { level: 9 }
    });

    archive.on('error', function(err) {
      throw err;
    });

    const archivePromise = new Promise((resolve, reject) => {
      output.on('close', resolve);
      archive.on('error', reject);
    });

    archive.pipe(output);
    archive.directory(`${__dirname}/${siteName}/`, false);
    await archive.finalize();
    await archivePromise;

    fs.rmSync(`${__dirname}/${siteName}`, { recursive: true, force: true });

    res.setHeader('Content-Type', 'application/zip');
    res.download(`${__dirname}/${siteName}.zip`, function(err) {
      if (err) {
        res.status(500).send('File downloading failed.');
      } else {
        fs.unlinkSync(`${__dirname}/${siteName}.zip`);
      }
    });

  } catch(err) {
    console.error(err);
    res.status(500).send('Error generating site files');
  }
});











app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
