<?php


$db-host = $_POST['db-host'];
$db-user = $_POST['db-user'];
$db-password = $_POST['db-password'];
$db-name = $_POST['db-name'];
$db-tables = $_POST['db-tables'];
$db-type = $_POST['db-type'];




?>