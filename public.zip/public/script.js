function changeTitle() {
  var titleElement = document.getElementById("title");
  titleElement.innerHTML = "Novo Título";
}

// Script para interatividade e manipulação do DOM

// Este arquivo não foi mencionado anteriormente, então aqui está um exemplo de como ele pode ser usado para adicionar funcionalidade interativa ao seu site.

document.addEventListener('DOMContentLoaded', (event) => {
  console.log('DOM carregado e analisado');
  
  // Adicione aqui seu código personalizado que será executado quando o DOM estiver pronto
  changeTitle();

  document.getElementById('site-generator-form').addEventListener('submit', function(event) {
    event.preventDefault();  // Evita o recarregamento da página

    var template = document.getElementById('template').value;

    switch (template) {
      case 'blog':
        generateBlogTemplate();
        break;
      case 'ecommerce':
        generateEcommerceTemplate();
        break;
      case 'portfolio':
        generatePortfolioTemplate();
        break;
    }
  });
});



function generateBlogTemplate() {
  var main = document.createElement('main');

  var article = document.createElement('article');
  main.appendChild(article);

  var h2 = document.createElement('h2');
  h2.textContent = 'Título do post do blog';
  article.appendChild(h2);

  var p = document.createElement('p');
  p.textContent = 'Conteúdo do post do blog...';
  article.appendChild(p);

  // Substituir o elemento <main> existente
  document.querySelector('main').replaceWith(main);
}


function generateEcommerceTemplate() {
  var main = document.createElement('main');

  var h2 = document.createElement('h2');
  h2.textContent = 'Nome do produto';
  main.appendChild(h2);

  var p = document.createElement('p');
  p.textContent = 'Descrição do produto...';
  main.appendChild(p);

  var img = document.createElement('img');
  img.src = 'https://via.placeholder.com/300x200';
  main.appendChild(img);

  // Substituir o elemento <main> existente
  document.querySelector('main').replaceWith(main);
}

function generatePortfolioTemplate() {
  var main = document.createElement('main');

  var h2 = document.createElement('h2');
  h2.textContent = 'Nome do projeto';
  main.appendChild(h2);

  var p = document.createElement('p');
  p.textContent = 'Descrição do projeto...';
  main.appendChild(p);

  var img = document.createElement('img');
  img.src = 'https://via.placeholder.com/300x200';
  main.appendChild(img);

  // Substituir o elemento <main> existente
  document.querySelector('main').replaceWith(main);
}


