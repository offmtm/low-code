const mysql = require('mysql');

// Atualize os detalhes abaixo com as informações da sua base de dados
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'meu_banco_de_dados' // adicione esta linha com o nome da sua base de dados
});

function generateSQL(siteData) {
  return `INSERT INTO Websites (name, template, colorScheme, image) VALUES ('${siteData.name}', '${siteData.template}', '${siteData.colorScheme}', '${siteData.image}')`;
}

connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to the database!');
});

module.exports = {
  saveSite: function(siteData) {
    return new Promise((resolve, reject) => {
      connection.changeUser({database : siteData.databaseName}, function(err) {
        if (err) {
          console.log('error in changing database', err);
          return;
        }
        // Agora você pode fazer a consulta
        let sql = generateSQL(siteData);
        connection.query(sql, (err, result) => {
          if (err) reject(err);
          resolve(result);
        });
      });
    });
  },
  queryDatabase: function(siteData) {
    return new Promise((resolve, reject) => {
      connection.changeUser({database : siteData.databaseName}, function(err) {
        if (err) {
          console.log('error in changing database', err);
          return;
        }
        // Agora você pode fazer a consulta
        connection.query('SELECT * FROM myTable', (err, result) => {
          if (err) reject(err);
          resolve(result);
        });
      });
    });
  }
};
