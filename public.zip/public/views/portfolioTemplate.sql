CREATE DATABASE IF NOT EXISTS portfolio;
USE portfolio;

CREATE TABLE portfolio_projects (
    id INT AUTO_INCREMENT,
    title VARCHAR(255),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(id)
);
