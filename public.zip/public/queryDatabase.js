const con = require('./dbConnection');

let sql = 'SELECT * FROM Users';
con.query(sql, function(err, result) {
    if (err) throw err;
    console.log('Resultado: ' + result);
});
