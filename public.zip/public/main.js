const form = document.getElementById('site-generator-form');

form.addEventListener('submit', (event) => {
  event.preventDefault();

  const formData = new FormData(form);
  const data = Object.fromEntries(formData);
  data.search_feature = document.getElementById('search-feature').checked;
  data.comments_feature = document.getElementById('comments-feature').checked;
  data.newsletter_feature = document.getElementById('newsletter-feature').checked;
  data.shopping_cart = document.getElementById('shopping-cart').checked;



  data.siteName = document.getElementById('siteName').value;
  data.siteType = document.getElementById('siteType').value;

  fetch('/create-site-files', { 
    method: 'POST', 
    body: JSON.stringify(data), 
    headers: { 'Content-Type': 'application/json' } 
  })
  .then(response => {
    if (!response.ok) {
      // if the server returned an error, print the error message
      return response.text().then(text => Promise.reject(text));
    }
    return response.blob(); // otherwise, continue with processing the response
  })
  .then(blob => {
    // create a blob URL and initiate a download
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${data.siteName}.zip`;
    document.body.appendChild(a); 
    a.click(); 
    a.remove();
  })
  .catch(error => {
    // print out any error messages
    console.error('Error:', error);
  });
});

$(document).ready(function() {
  $("#connect-btn").on('click', function() {
      // Collecting the data from the form
      let dbType = $("#db-type").val();
      let dbHost = $("#db-host").val();
      let dbUser = $("#db-user").val();
      let dbPassword = $("#db-password").val();
      let dbName = $("#db-name").val();
      let dbTables = $("#db-tables").val();

      // Sending the data to the server
      $.ajax({
          type: "POST",
          url: "/connect",
          data: {
              dbType: dbType,
              dbHost: dbHost,
              dbUser: dbUser,
              dbPassword: dbPassword,
              dbName: dbName,
              dbTables: dbTables
          },
          success: function(response) {
              alert(response);
          },
          error: function(error) {
              alert('Failed to connect: ' + error.responseText);
          }
      });
  });
});

